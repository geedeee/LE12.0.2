#define DEBUG 1
#define VERSION "3.14.14"
#define ADATE   "31 May 2016"

#define APCUPSD_RELEASE VERSION

#ifndef APCUPSD_HOST
# define APCUPSD_HOST HOST
#endif
