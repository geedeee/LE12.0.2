?package(apcupsd):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="apcupsd" command="/usr/bin/apcupsd"
